# 비교 연산자
# 211015 백찬현


while True :
    try :
        score=int(input("점수를 입력하세요 : "))
        if score  >= 0 and score <= 100 :
                

            if score >=95 :
                print("A+ Great" )

            elif score >=90 :
                print("A Nice")
            elif score >=85 :
                print("B+ Better"  )
            elif score >=80 :
                print("B Good" )        
            elif score >=75 :
                print("C+" )
            elif score >=70 :
                print("C" )
            elif score >=65 :
                print("D+" )
            elif score >=60 :
                print("D" )    
            else :
                print("F ^^ " )
             
        else :
                print("0에서 100사이의 숫자를 입력하세요")
    except ValueError:
        print("정수를 입력해주세요.")
        continue
