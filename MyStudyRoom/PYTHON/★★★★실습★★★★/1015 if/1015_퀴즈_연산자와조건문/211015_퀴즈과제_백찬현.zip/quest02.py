# 논리 연산자
# 211015 백찬현



while True :
    try :
        gen = int(input("성별을 입력하세요 : (남성  1 , 여성 2)"))
        kg = int(input("체중을 입력하세요 :"))

        if gen == 1 :

            if kg >= 85 :
                print("과체중 입니다 운동하세요")
            elif kg >= 50 and kg < 85 :
                print("표준체중 입니다 현 페이스 유지하세요")
            elif kg < 50 :
                print("표준체중 이하 입니다 고기 드세요") 
            else :
                print("")
        else :
            print("")

        if gen == 2 :
  
            if kg >= 68 :
                print("과체중 입니다 운동하세요")
            elif kg >= 40 and kg < 68 :
                print("표준체중 입니다 현 페이스 유지하세요")
            elif kg < 40 :
                print("표준체중 이하 입니다 고기 드세요")
            else :
                print("")
        else : 
            print("")

    except ValueError:
        print("숫자를 입력해주세요.")
        continue


                   

      
        
