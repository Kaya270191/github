# 문제 1 산술연산자
# 신채연 _ 20211015


while True:

    hap=0    
    number = input("다섯자리 정수를 입력하시오!! : ")

    if len(number)>5:
        print("다시 입력하세요.")
        continue
    
    try:
        number = int(number)
    except:
        number = -1

    if number==-1:
        print("다시 입력하세요.")
        continue

        

    for i in range(4,-1,-1):
        val = number//(10**i)
        hap +=val
        number = number - val*(10**i)
        if i == 0:
            print(val, end=" = ")
        else:
            print(val, end=" + ")

    print(hap)
