#문제3 비교연산자
#신채연_20211015


score = int(input("성적을 입력하세요: "))

print("축하합니다. ")
if score>=95:
    print("A+", end="")
elif score>=90:
    print("A", end="")
elif score>=85:
    print("B+", end="")
elif score>=80:
    print("B", end="")
elif score>=75:
    print("C+", end="")
elif score>=70:
     print("C", end="")
elif score>=65:
    print("D+", end="")
elif score>=60:
    print("D", end="")
else:
    print("F", end="")

print(" 학점입니다.")










          

