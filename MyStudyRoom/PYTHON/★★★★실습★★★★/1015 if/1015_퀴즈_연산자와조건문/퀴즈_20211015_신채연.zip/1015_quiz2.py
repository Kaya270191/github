# 문제 2 논리연산자
# 신채연 _ 20211015

gender = int(input("성별을 입력하세요: <남성 1, 여성 2>: "))
weight = int(input("체중을 입력하세요: "))

if gender ==1:
    if weight >=85:
        print("과체중입니다. 운동하세요.")
    elif weight >= 50 and weight <85 :
        print("표준체중입니다. 현 페이스 유지하세요.")
    elif weight < 50:
        print("표준체중 이하입니다. 고기 드세요.")
elif gender ==2:
    if weight >=68:
        print("과체중입니다. 운동하세요.")
    elif weight >= 40 and weight <68 :
        print("표준체중입니다. 현 페이스 유지하세요.")
    elif weight < 40:
        print("표준체중 이하입니다. 고기 드세요.")
