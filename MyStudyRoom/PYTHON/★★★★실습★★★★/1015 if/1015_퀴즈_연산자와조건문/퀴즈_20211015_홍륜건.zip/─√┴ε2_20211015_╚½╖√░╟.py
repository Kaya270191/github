#20211015 홍륜건
while True:
        s = int(input("성별을 입력하세요:<남성 1, 여성2>:"))
        w = int(input("체중을 입력하세요:"))
        
        a = "과체중 입니다, 운동하세요"
        b = "표준체중 입니다. 현 페이스 유지하세요"
        c = "표준체중 이하 입니다. 고기 드세요"            
        if s == 1:
            if w >= 85: 
                print(a)
            elif w >= 50:
                print(b)
            else:
                print(c)
        elif s == 2:
            if w >= 68:
                print(a)
            elif w >= 40:
                print(b)
            else:
                print(c)
