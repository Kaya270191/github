#20211015 홍륜건
while True:
    n = int(input("성적을 입력하세요:"))
    if n>100:
        continue
    elif n>= 95:
        print("축하합니다. A+입니다")
    elif n >= 90:
        print("축하합니다. A입니다")
    elif n >= 85:
        print("축하합니다. B+입니다")
    elif n >= 80:
        print("축하합니다. B입니다")
    elif n >= 75:
        print("축하합니다. C+입니다")
    elif n >= 70:
        print("축하합니다. C입니다")
    elif n >= 65:
        print("축하합니다. D+입니다")
    elif n >= 60:
        print("축하합니다. D입니다")
    else:
        print("축하합니다. F입니다")


