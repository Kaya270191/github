#20211015홍륜건
while True:
    n = int(input('다섯자리 정수를 입력하시오!!'))
    print(n, end=" ")
    list1 = list(map(int,str(n)))
    s=0
    for i in list1:
        s += i
    print()  
    list1.insert(1,"+")
    list1.insert(3,"+")
    list1.insert(5,"+")
    list1.insert(7,"+")
    list1.insert(9,"=")
    list1.insert(11,s)

    for i in list1:
        print(i ,end="" )
'''
                




               
            

'''
