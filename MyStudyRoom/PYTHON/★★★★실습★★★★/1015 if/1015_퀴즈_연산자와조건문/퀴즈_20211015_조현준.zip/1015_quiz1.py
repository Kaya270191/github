#20211015_조현준
#개요
'''
다섯자리 정수값을 입력받고 각 정수값의 합을 구하는 프로그램
'''

#설계
'''
1. 다섯자리 정수값을 입력받는다.
2. 리스트를 활용해 입력받은 정수값을 문자열 리스트로 변환시키는 변수를 지정한다.
3. 입력값이 다섯 자리 미만이면 값을 다시 입력 받는다.
4. 입력값이 다섯자리 초과면 값을 다시 입력 받는다.
5. 입력받은 정수값을 문자열로 바꾸고 for문을 실행한다.
6. for문을 반복할때마다 총합에  i값에 더한다
7. 리스트의 각 자리수를 출력하고 합을 출력한다
'''

#구현
while True:
    try:
        num=int(input("다섯자리 정수값을 입력해주세요 : "))
        numlist=list(map(int,str(num)))
        hap=0
        if len(str(num))>=6:
            print("!!!다섯 자리보다 많게 입력했습니다!!!")
            continue
        elif len(str(num))<5:
            print("!!!다섯 자리보다 적게 입력했습니다!!")
            continue
        else:
            for i in str(num):
                hap += int(i)
            print(numlist[0],'+',numlist[1],'+',numlist[2],'+',numlist[3],'+',numlist[4],'=',hap)
    except :
        print("숫자만 입력해주세요!!")


    
    



    
