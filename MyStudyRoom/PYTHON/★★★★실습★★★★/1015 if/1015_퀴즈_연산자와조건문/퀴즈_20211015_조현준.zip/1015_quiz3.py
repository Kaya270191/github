#20211015_조현준
#개요
'''
학생들의 성적을 입력 받고 성적 조건에 맞는 학점을 출력해보자
'''

#설계
'''
1. 점수를 입력받는다.
2. 입력받은 점수가 0~100인지 판단한다.
3. 입력받은 값이 정수가 아닐경우 다시 입력 받는다
4. if ~ elif를 이용해 점수에 맞는 학점을 출력한다.
성적 조건
입력값 >= 95 A+
입력값 >= 90 A
입력값 >= 85 B+
입력값 >= 80 B
입력값 >= 75 C+
입력값 >= 70 C
입력값 >= 65 D+
입력값 >= 60 D
입력값 < 60 F
'''

#구현
while True :
    try:
        s=int(input('점수를 입력해주세요 : '))
        if s>100 or s<0:
            print('0~100까지의 수만 입력해주세요!!')
            continue
        if s >= 95 :
            print('A+!!',end='')
        elif s >=90 :
            print('A!',end='')
        elif s >=85 :
            print('B+',end='')
        elif s >=80 :
            print('B',end='')
        elif s >=75:
            print('C+',end='')
        elif s >=70 :
            print('C!',end='')
        elif s >=65 :
            print('D+!',end='')
        elif s >=60 :
            print('D',end='')
        else:
            print('Fㅜㅜ',end='')  
        print(' 학점 입니다!')
    except:
        print('숫자만 입력해주세요')
        continue