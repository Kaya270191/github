#20211015_조현준
#개요
'''
사용자로부터 성별과 몸무게를 입력 받고, 입력 받은 값에 따른 비만도 출력
'''

#설계
'''
1.사용자로부터 성별을 입력받는다.
2.사용자로부터 몸무게를 입력받는다.
3.if~elif를 활용해 남성일 경우에 비만측정표에 따른 문구를 출력한다.
4.여성일 경우 비만측정표에 따른 문구를 출력한다.

'''

#구현
while True :
    s=int(input("성별을 선택해주세요 1.남성 2.여성 :"))
    if s > 2 :
        print("성별을 제대로 입력해주세요.")
        continue
    w=int(input("몸무게를 입력해주세요 : "))
    mf=int(85)
    ms=int(50)
    wf=int(68)
    ws=int(40)
    if s == 1 and w >= mf :
        print('평균 남성보다 과체중입니다. 살빼세요.')
    elif s == 1 and ms <= w < mf :
        print('남성 평균입니다. 유지하세요.')
    elif s ==1 and w < ms :
        print('평균 남성보다 저체중입니다. 더 드세요')
    elif s == 2 and w > wf :
        print('평균 여성보다 과체중입니다. 살빼세요.')
    elif s == 2 and ws <= w < wf :
        print('여성 평균입니다. 유지하세요.')
    elif s == 2 and w < ws :
        print('평균 여성보다 저체중입니다. 더 드세요')
    else :
        print('사람이 맞습니까?')
        break

