#문제2 논리 연산자
#공인배_2021-10-15

while True:
    
    a=int(input("성별을 입력하세요 <남성 1, 여성2> :"))

    if a <0 or a>3:
        continue

    if a ==1:
        b=int(input("체중을 입력하세요:"))
        if b >=85:
            print("과체중 입니다. 운동하세요.")
        elif b >=50:
            print("표준체중 입니다. 현 페이스 유지하세요")
        else :
            print("표준체중 이하 입니다. 고기 드세요.")


    if a==2:
        c=int(input("체중을 입력하세요"))
        if c >=68:
            print("과체중 입니다. 운동하세요")
        elif c >=40:
            print("표준체중 입니다. 현 페이스 유지하세요")
        else :
            print("표준체중 이하 입니다. 고기 드세요")
    d=input("계속하려면 아무키나 누르십시오!")
    if d :
        continue
