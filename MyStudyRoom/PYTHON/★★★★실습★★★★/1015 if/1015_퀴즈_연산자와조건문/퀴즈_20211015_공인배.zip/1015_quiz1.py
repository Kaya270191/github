#문제1 산술연산자
#공인배_2021-10-15

while True :
    num1, num2, num3, num4, num5 =map(int,input("정수 다섯 개 입력하시오!! : "))

    print("%d+ %d +%d + %d+ %d = %d" % ( num1, num2, num3, num4, num5, num1+num2+num3+num4+num5))
    a=input("계속하려면 아무키나 누르십시오!")
    if a :
        continue
    
