while True:
    a = int(input("다섯 자리 정수를 입력하시오.: "))

    b = (a//10000)
    c = (a//1000 % 10)
    d = (a//100 % 10)
    e = (a//10 % 10)
    f = (a//1 % 10)

    print("%d + %d + %d + %d + %d = %d " %(b,c,d,e,f ,b+c+d+e+f))
