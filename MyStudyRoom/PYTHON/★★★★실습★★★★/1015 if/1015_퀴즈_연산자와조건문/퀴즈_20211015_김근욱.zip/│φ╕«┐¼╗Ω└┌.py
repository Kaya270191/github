while True:
    a = int(input("성별을 입력하시오. : < 1. 남성 2. 여성 >"))

    if a == 1:
        b = int(input("체중을 입력하시오. : "))
        if b >= 85:
            print("과체중 입니다. 운동하세요.")
        elif b < 85 and b >= 50:
            print("표준 체중입니다. 현 페이스 유지하세요.")
        else:
            print("표준 체중 이하 입니다. 고기 드세요.")

    if a == 2:
        c = int(input("체중을 입력하시오. : "))
        if c >= 68:
            print("과체중 입니다. 운동하세요.")
        elif c < 68 and c >= 40:
            print("표준 체중입니다. 현 페이스 유지하세요.")
        else:
            print("표준 체중 이하 입니다. 고기 드세요.")
