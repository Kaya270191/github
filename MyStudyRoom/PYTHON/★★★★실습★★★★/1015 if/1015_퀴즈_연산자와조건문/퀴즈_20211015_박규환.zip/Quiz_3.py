#박규환 21.10.15
while True :
    try :
        score=int(input("점수를 입력하세요 : "))
        if score < 0 or score > 100 :
            continue

        if score>=95 :
            print("A+",end=" ")
        elif score>=90 :
            print("A",end=" ")
        elif score>=85 :
            print("B+",end=" ")
        elif score>=80 :
            print("B",end=" ")
        elif score>=75 :
            print("C+",end=" ")
        elif score>=70 :
            print("C",end=" ")
        elif score>=65 :
            print("D+",end=" ")
        elif score>=60 :
            print("D",end=" ")
        else :
            print("F",end=" ")

        print("학점입니다.")
    except :
        print("오류가 발생하였습니다.")
        continue
