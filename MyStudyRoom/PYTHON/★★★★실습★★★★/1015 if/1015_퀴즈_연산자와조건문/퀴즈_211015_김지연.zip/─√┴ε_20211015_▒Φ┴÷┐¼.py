#김지연-1015_문제1 산술연산자

while True: #조건이 참인동안 계속 반복
    sum = 0
    str = ""
    s=input("다섯자리 정수를 입력하세요! :") #사용자에게 다섯자리 정수 입력받기
    if s == "":  #아무것도 입력하지 않을 경우 다시 정수 입력받기
        break
    for i in s: 
        sum += int(i)
        str = str + '+' + i #숫자를 문자열로 변환
    str=str.replace('+','',1)
    print(str,'=',sum)
    
