#김지연-1015-문제3. 비교연산자

while True:
    s=int(input("성적을 입력해주세요: ")) #사용자의 성적 입력

    if s<0: #정확한 성적 입력을 위함
        print("정확한 성적을 입력해주세요.")
        continue
    if s>100:
        print("정확한 성적을 입력해주세요.")
        continue
    
    if s >=95:
        print("축하합니다. A+입니다.")
    elif s>=90:
        print("축하합니다. A입니다.")
    elif s>=85:
        print("축하합니다. B+입니다.")
    elif s>=80:
        print("수고하셨습니다. B입니다.")
    elif s>=75:
        print("안타깝게도 C+입니다.")
    elif s>=70:
        print("안타깝게도 . C입니다.")
    elif s>=60:
        print("조금 더 노력하세요. D입니다.")
    elif s<60:
        print("큰일입니다. F입니다.")
            

