#구보은 20211015

while True:
    
    sc= int(input("성적을 입려하세요. : ")) #sc 변수선언

    if 101>sc>=95:
        print("축하합니다. A+ 입니다.")             #if~elif를 통해 성적계산 
    elif sc>=90:
        print("축하합니다. A 입니다.")
    elif sc>=85:
        print("축하합니다. B+ 입니다.")
    elif sc>=80:
        print("축하합니다. B 입니다.")
    elif sc>=75:
        print("축하합니다. C+ 입니다.")
    elif sc>=70:
        print("축하합니다. C 입니다.")
    elif sc>=65:
        print("축하합니다. D+ 입니다.")
    elif sc>=60:
        print("축하합니다. D 입니다.")

    else :
        print("F입니다.")

    keep=input("계속하시려면 아무키나 누르세요")
    if keep:
        continue
