#구보은 20211015
#산술연산자 실습1
while True:         #프로그램을 반복하기위해입력.

    str=input("다섯자리 정수를 입력하시오!!")#str을 이용해 숫자형태 문자5개를 하나씩 접근할수있도록.
    a=int(str[0])
    b=int(str[1])
    c=int(str[2])   #int(str[n]) : n번째 문자를 정수형태로 변환
    d=int(str[3])
    e=int(str[4])

    result =a+b+c+d+e #result 변수선언
    print("%d+%d+%d+%d+%d=%d" %(a,b,c,d,e,result))
    

    keep=input("계속하려면 아무키나 누르십시오...")
    if keep:
        continue
