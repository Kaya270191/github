#비교연산자   1015_이종훈
while True :
    try :
        score=int(input("성적을 입력하세요 : "))

        if score<0 or score>100 :    
            continue

        if score>=95 :
            print("A+", end="")  
        elif score >= 90 :
            print("축하합니다. A", end="")
        elif score >= 85 :
            print("축하합니다.B+", end="")
        elif score >= 80 :
            print("축하합니다.B", end="")
        elif score >= 75 :
            print("축하합니다.C+", end="")
        elif score >= 70 :
            print("축하합니다.C", end="")
        elif score >= 65 :
            print("축하합니다.D+", end="")
        elif score >= 60 :
            print("축하합니다.D", end="")
         
        else :
            print("축하합니다.F ^^;;", end="")

        print("입니다. ")
    except ValueError:
        print("정수를 입력해주세요.")
    a=input("계속하려면 아무키나 누르십시오...")
    if a:
        continue

