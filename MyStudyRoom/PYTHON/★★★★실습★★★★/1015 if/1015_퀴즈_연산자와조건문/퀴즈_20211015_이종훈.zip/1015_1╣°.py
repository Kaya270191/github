# 문제1: 산술 연산자 1015_이종훈

while True :
    num1, num2, num3, num4, num5 =map(int,input("다섯자리 정수를 입력하시오!!: "))

    print("{} + {} + {} + {} + {} = {}".format(num1, num2, num3, num4, num5, num1+num2+num3+num4+num5))
    a=input("계속하려면 아무키나 누르십시오!")
    if a :
        continue
