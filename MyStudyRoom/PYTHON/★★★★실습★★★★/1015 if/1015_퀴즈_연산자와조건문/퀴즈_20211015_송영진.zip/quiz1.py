# 21/10/15 송영진

num = input("Enter a 5-digit number!!\n")
print(("{} + "*4 + "{} = {}").format(*num, sum(map(int, num))))
