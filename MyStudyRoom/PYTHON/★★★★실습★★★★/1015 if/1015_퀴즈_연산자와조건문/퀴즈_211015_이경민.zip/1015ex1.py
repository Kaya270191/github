#21.10.15 이경민 산술연산자

#변수선언
number=0

#메인코드


number=int(input("다섯자리 정수를 입력하시오!!"))
x=str(number)
sum=int(x[0:1])+int(x[1:2])+int(x[2:3])+int(x[3:4])+int(x[4:5])
print("%d+%d+%d+%d+%d=%d"%(int(x[0:1]),int(x[1:2]),int(x[2:3]),int(x[3:4]),int(x[4:5]),int(sum)))






                        
