#1015 김명진

while 1 : #반복문 실행

    a= int(input("점수를 입력하세요"))  #점수 입력

    if a>=95 :
        print("A+ 학점 입니다.")
    elif a>=90 :
        print("A 학점 입니다.")
    elif a>=85 :
        print("B+ 학점 입니다.")
    elif a>=80 :
        print("B 학점 입니다.")
    elif a>=75 :
        print("C+ 학점 입니다.")
    elif a>=70 :
        print("C 학점 입니다.")
    elif a>=65 :
        print("D+ 학점 입니다.")
    elif a>=60 :
        print("D 학점 입니다.")
    else :
        print("F 학점 입니다.")
