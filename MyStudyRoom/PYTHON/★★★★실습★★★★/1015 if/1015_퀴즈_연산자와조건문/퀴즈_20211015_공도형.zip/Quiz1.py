num = int(input("다섯자리 정수를 입력하시오!!"))


#각 자리 정수 구하기
a = int(num/10000)

while 1:
    if num>9999:
        num = num - 10000
        b = int(num/1000)
    else:
        break

while 1:
    if num>999:
        num = num - 1000
        c = int(num/100)
    else:
        break

while 1:
    if num>99:
        num = num - 100
        d = int(num/10)
    else:
        break

while 1:
    if num>9:
        num = num - 10
        e = int(num)
    else:
        break


#각 정수 더하기
i = a + b + c + d + e

#출력
print("%d + % d + % d + % d + % d = %d" % (a, b, c, d, e, i))


    
    
    
