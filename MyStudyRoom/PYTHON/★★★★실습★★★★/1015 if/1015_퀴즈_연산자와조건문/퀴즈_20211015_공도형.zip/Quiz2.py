i='과체중입니다 운동하세요'
o='표준체중입니다 현 페이스 유지하세요'
p='표준체중 이하 입니다 고기 드세요'

while 1:
    a = int(input("성별을 입력하세요: <남성1, 여성2>: "))

    # 1이나 2가 아닐경우 재시작
    if a!=1 and a!=2:
        print("재입력해주세요")
        continue

    # 1이나 2라면 진행
    if a==1 or a==2:
        b = int(input("체중을 입력하세요: "))
        
        # 남자일 경우
        if a==1:
            if b >= 85:
                print(i)
            elif b >= 50:
                print(o)
            elif b < 50:
                print(p)
                
        # 여자일 경우
        elif a==2:
            if b >= 68:
                print(i)
            elif b >= 40:
                print(o)
            elif b < 40:
                print(p)
                
        break #<<반복하고 싶으면 del 
