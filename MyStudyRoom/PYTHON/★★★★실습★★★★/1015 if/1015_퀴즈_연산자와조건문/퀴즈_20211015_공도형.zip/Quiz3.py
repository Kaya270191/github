while 1:
    score=int(input("점수를 입력하세요 : "))
    if score>100 or score<0:
        print("다시입력해주세요")
        continue
    else:        
        if score>100 or score<0:
            continue
        if score>=95:
            i="A+"
        elif score>=90:
            i="A"
        elif score>=85:
            i="B+"
        elif score>=80:
            i="B"
        elif score>=75:
            i="C+"
        elif score>=70:
            i="C"
        elif score>=65:
            i="D+"
        elif score>=60:
            i="D"
        else:
            i="F"
        print("축하합니다", i,"학점입니다")
