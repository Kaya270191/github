#최채호 20211015
result = 0
while 1 :
    try :
        num1 = input("다섯자리정수를 입력하세요!! : ")
        if len(num1) > 5 :
              print('다섯 자리정수가 아닙니다. \n다시 입력하세요')
              continue
        print("입력하신 숫자들은 : ")
        for num2 in str(num1) :
            print(num2,end=" ")
        print(" ")
        print("입력하신 숫자의 더하기 공식 : ")
        print(f"{num1[0]} + {num1[1]} + {num1[2]} + {num1[3]} + {num1[4]} ")
        for num2 in num1 :
            result += int(num2)
        print("총합 : ")
        print(result)
        
        input("계속 할려면 아무 키나 누르십시오...")
    except ValueError:
        print("정수를 입력해주세요.")
        continue        
