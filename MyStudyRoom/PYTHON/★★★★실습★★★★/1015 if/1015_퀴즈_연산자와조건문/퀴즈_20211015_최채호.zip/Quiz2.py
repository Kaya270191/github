#최채호 20211015
weight = 0
while 1 :
    try :
        sex = int(input("남성이면 1번, 여성이면 2번을 입력 해주세요."))
        if sex == 1 :
            print('남성를 선택 하셨습니다.')
            weight = int(input("몸무게를 입력해주세요. : "))
            ch = ["표준체중 이하","표준","과체중"]
            if weight >= 85:
                print(f"당신의 몸무게는 {ch[2]} 입니다")
            elif weight >= 60:
                print(f"당신의 몸무게는 {ch[1]} 입니다")
            else :
                print(f"당신의 몸무게는 {ch[0]} 입니다")
              
            input("계속 할려면 아무 키나 누르십시오...")
            continue
        if sex == 2 :
            print('여성를 선택 하셨습니다.')
            weight = int(input("몸무게를 입력해주세요. : "))
            ch = ["표준체중 이하","표준","과체중"]
            if weight >= 68:
                print(f"당신의 몸무게는 {ch[2]} 입니다")
            elif weight >= 40:
                print(f"당신의 몸무게는 {ch[1]} 입니다")
            else :
                print(f"당신의 몸무게는 {ch[0]} 입니다")
              
            input("계속 할려면 아무 키나 누르십시오...")
            continue
    except ValueError:
        print("정수를 입력해주세요.")

   
