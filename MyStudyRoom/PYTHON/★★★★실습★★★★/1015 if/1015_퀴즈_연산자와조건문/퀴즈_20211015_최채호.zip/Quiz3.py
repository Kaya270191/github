#최채호 20211015
score = 0
while 1 :
    try :
            score = int(input("성적를 입력해주세요. : "))
            ch = ["A+", "A", "B+", "B", "C+", "C", "D+", "D", "F"]
            if score >= 95:
                print(f"당신의 성적은 {ch[0]} 입니다")
            elif score >= 90:
                print(f"당신의 성적은 {ch[1]} 입니다")
            elif score >= 85:
                print(f"당신의 성적은 {ch[2]} 입니다")
            elif score >= 80:
                print(f"당신의 성적은 {ch[3]} 입니다")
            elif score >= 75:
                print(f"당신의 성적은 {ch[4]} 입니다")
            elif score >= 70:
                print(f"당신의 성적은 {ch[5]} 입니다")
            elif score >= 65:
                print(f"당신의 성적은 {ch[6]} 입니다")
            elif score >= 60:
                print(f"당신의 성적은 {ch[7]} 입니다")
            else :
                print(f"당신의 성적은 {ch[8]} 입니다")
              
            input("계속 할려면 아무 키나 누르십시오...")
            continue
    except ValueError:
        print("정수를 입력해주세요.")
        continue        

   
