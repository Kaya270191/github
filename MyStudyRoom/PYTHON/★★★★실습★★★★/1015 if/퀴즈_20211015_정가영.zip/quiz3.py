while True:

    a=int(input("성적을 입력하세요: "))

    if a>=95:
        print("축하합니다. A+입니다.")

    elif a>=90:
        print("축하합니다. A입니다.")

    elif a>=85:
        print("축하합니다. B+입니다.")

    elif a>=80:
        print("축하합니다. B입니다.")

    elif a>=75:
        print("축하합니다. C+입니다.")

    elif a>=70:
        print("축하합니다. C입니다.")

    elif a>=65:
        print("축하합니다. D+입니다.")

    elif a>=60:
        print("축하합니다. D입니다.")

    else:
        print("축하합니다. F입니다. ^^;;")

    input("계속하려면 아무 키나 누르십시오...")
    
